#__main__.py

from mintmap.app import App


def run():
    App().run()


if __name__ == "__main__":
    run()
