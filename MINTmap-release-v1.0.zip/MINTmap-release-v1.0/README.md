# MINTmap
If you are viewing this from the github.com website, this is the code repository for MINTmap.  If you just want to download the latest version for basic usage, please visit https://cm.jefferson.edu/MINTmap/ and follow the MINTmap download link there.

The file README_and_LICENSE.txt contains information on how to run the tool and license information.
